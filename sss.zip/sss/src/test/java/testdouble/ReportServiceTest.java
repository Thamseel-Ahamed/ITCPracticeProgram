package testdouble;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ReportServiceTest {
	@Test
	public void testGenerateReport() {
		mailservice dummyEmail = new DummyEmailService(); //Not used
		reportservice reportService = new reportservice(dummyEmail);
		
		String result = reportService.generateReport();
		Assert.assertEquals(result, "Report Generated");
	}

}
