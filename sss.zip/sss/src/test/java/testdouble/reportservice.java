package testdouble;

public class reportservice {
	private mailservice emailService;
	public reportservice(mailservice emaiService) {
		this.emailService = emailService;
		}
	public String generateReport() {
		//Email is not used in this method, but needed in constructor
		return "Report Generated";
	}
}
