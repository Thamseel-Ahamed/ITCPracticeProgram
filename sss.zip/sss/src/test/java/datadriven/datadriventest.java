package datadriven;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
public class datadriventest {
    WebDriver driver;
    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/");
    }
    @DataProvider(name = "loginData")
    public Object[][] loginDataProvider() {
        return new Object[][] {
            {"student", "SuperSecr"},
            {"tomsmith", "password"},
            {"student", "Password123"},
            {"student", "Password123"},
            {"tomsmith", "Super"}
        };
    }
    @Test(dataProvider = "loginData")
    public void testLogin(String username, String password) {
        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement loginBtn = driver.findElement(By.id("submit"));
        usernameField.clear();
        usernameField.sendKeys(username);
        passwordField.clear();
        passwordField.sendKeys(password);
        loginBtn.click();
        // You can add validation/assertion here
        System.out.println("Tested login with: " + username + " / " + password);
    }
    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}

