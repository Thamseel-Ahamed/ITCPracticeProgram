package button;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class iframe {
    public static void main(String[] args) throws InterruptedException {
        // Step 1: Setup ChromeDriver
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        // Step 2: Open the test page with iframe
        driver.get("https://the-internet.herokuapp.com/iframe");
        Thread.sleep(2000);
        // Step 3: Switch to the iframe using ID or WebElement
        driver.switchTo().frame("mce_0_ifr"); // You can also use WebElement if needed
        // Step 4: Interact with elements inside iframe (TinyMCE editor)
        WebElement editor = driver.findElement(By.id("tinymce"));
        editor.clear(); // Clear existing content
        editor.sendKeys("Hello from Selenium!");
        // Step 5: Switch back to the main content
        driver.switchTo().defaultContent();
        // Step 6: Print main page heading or title
        String heading = driver.findElement(By.tagName("h3")).getText();
        System.out.println("Main page heading: " + heading);
        // Step 7: Close the browser
        driver.quit();
    }
}
