package testdouble;

public interface mailservice {
	void sendEmail(String message);
}
