package testsuite;

import org.testng.annotations.Test;

public class LoginTest {
  @Test
  public void testValidLogin() {
	  System.out.println("Login test passed");
  }
}
