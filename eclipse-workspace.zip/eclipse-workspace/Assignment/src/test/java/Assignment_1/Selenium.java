package Assignment_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class Selenium {
    public static void main(String[] args) {
        // Set ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
        // Launch browser
        WebDriver driver = new ChromeDriver();
        // Open local test page
        driver.get("https://demoqa.com/automation-practice-form#google_vignette");  // <-- Replace with your file path
        // 1. Text input field
        WebElement username = driver.findElement(By.id("firstname"));
        username.sendKeys("Thamseel");
        WebElement Lastname = driver.findElement(By.id("lastname"));
        username.sendKeys("Ahamed");
        // 2. Password field
        WebElement password = driver.findElement(By.id("userEmail"));
        password.sendKeys("thamseelahamed135@gmail.com");
        // 3. Checkbox
        WebElement Mobilenumber = driver.findElement(By.id("userNumber"));
        Mobilenumber.sendKeys("8072422456");
        // 4. Radio button
        WebElement radio = driver.findElement(By.xpath("//label[normalize-space()='Male']"));
        radio.click();
        // 5. Dropdown menu
        Select dropdown = new Select(driver.findElement(By.id("dropdown")));
        dropdown.selectByValue("2");
        // 6. Button (triggers alert)
        WebElement button = driver.findElement(By.tagName("button"));
        button.click();
        // 7. Handle alert
        driver.switchTo().alert().accept();
        // 8. Click on a link
        WebElement link = driver.findElement(By.id("exampleLink"));
        link.click();
        // Done – close browser
        try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }
        driver.quit();
    }
}
