package steps;
import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class RegisterSteps {
    WebDriver driver;
    @Given("the user navigates to the PetStore registration page")
    public void the_user_navigates_to_the_PetStore_registration_page() {
        // Initialize ChromeDriver (Make sure chromedriver is in your system PATH or specify its path)
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://petstore.octoperf.com/actions/Account.action?newAccountForm=");
    }
    @When("the user enters username {string}")
    public void the_user_enters_username(String username) {
        driver.findElement(By.name("username")).sendKeys(username);
    }
    @When("the user enters password {string}")
    public void the_user_enters_password(String password) {
        driver.findElement(By.name("password")).sendKeys(password);
    }
    @When("the user repeats password {string}")
    public void the_user_repeats_password(String password) {
        driver.findElement(By.name("repeatedPassword")).sendKeys(password);
    }
    @When("the user enters first name {string}")
    public void the_user_enters_first_name(String firstName) {
        driver.findElement(By.name("account.firstName")).sendKeys(firstName);
    }
    @When("the user enters last name {string}")
    public void the_user_enters_last_name(String lastName) {
        driver.findElement(By.name("account.lastName")).sendKeys(lastName);
    }
    @When("the user enters email address {string}")
    public void the_user_enters_email_address(String email) {
        driver.findElement(By.name("account.email")).sendKeys(email);
    }
    @When("the user enters phone number {string}")
    public void the_user_enters_phone_number(String phone) {
        driver.findElement(By.name("account.phone")).sendKeys(phone);
    }
    @When("the user enters address line 1 {string}")
    public void the_user_enters_address_line_1(String address1) {
        driver.findElement(By.name("account.address1")).sendKeys(address1);
    }
    @When("the user enters address line 2 {string}")
    public void the_user_enters_address_line_2(String address2) {
        driver.findElement(By.name("account.address2")).sendKeys(address2);
    }
    @When("the user enters city {string}")
    public void the_user_enters_city(String city) {
        driver.findElement(By.name("account.city")).sendKeys(city);
    }
    @When("the user enters state {string}")
    public void the_user_enters_state(String state) {
        driver.findElement(By.name("account.state")).sendKeys(state);
    }
    @When("the user enters zip code {string}")
    public void the_user_enters_zip_code(String zip) {
        driver.findElement(By.name("account.zip")).sendKeys(zip);
    }
    @When("the user enters country {string}")
    public void the_user_enters_country(String country) {
        driver.findElement(By.name("account.country")).sendKeys(country);
    }
    @When("the user selects preferred language {string}")
    public void the_user_selects_preferred_language(String language) {
        Select languageDropdown = new Select(driver.findElement(By.name("account.languagePreference")));
        languageDropdown.selectByVisibleText(language);
    }
    @When("the user selects favorite category {string}")
    public void the_user_selects_favorite_category(String category) {
        Select categoryDropdown = new Select(driver.findElement(By.name("account.favouriteCategoryId")));
        categoryDropdown.selectByVisibleText(category);
    }
    @When("the user enables MyList {string}")
    public void the_user_enables_MyList(String value) {
        if (value.equalsIgnoreCase("true")) {
            driver.findElement(By.name("account.listOption")).click();
        }
    }
    @When("the user enables MyBanner {string}")
    public void the_user_enables_MyBanner(String value) {
        if (value.equalsIgnoreCase("true")) {
            driver.findElement(By.name("account.bannerOption")).click();
        }
    }
    @When("the user clicks the {string} button")
    public void the_user_clicks_the_button(String buttonName) {
        // The only button for saving account information has name "newAccount"
        driver.findElement(By.name("newAccount")).click();
    }
    @Then("the account should be successfully created")
    public void the_account_should_be_successfully_created() {
        // Check for a success message or welcome message in page source (adjust as needed)
        boolean isSuccess = driver.getPageSource().contains("Welcome");
        if (!isSuccess) {
            throw new AssertionError("Account creation failed.");
        }
        // Close the browser after verification
        driver.quit();
    }
}
