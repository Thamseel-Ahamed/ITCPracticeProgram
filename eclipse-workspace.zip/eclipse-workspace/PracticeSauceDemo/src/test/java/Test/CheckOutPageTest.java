package Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import page.Loginpage;
import page.InventoryPage;
import page.CartPage;
import page.CheckoutPage;

import java.time.Duration;

public class CheckOutPageTest {

    WebDriver driver;
    Loginpage loginPage;
    InventoryPage inventoryPage;
    CartPage cartPage;
    CheckoutPage checkoutPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver-win64//chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");

        loginPage = new Loginpage(driver);
        inventoryPage = new InventoryPage(driver);
        cartPage = new CartPage(driver);
        checkoutPage = new CheckoutPage(driver);

        try {
            // Login and navigate to checkout page
            loginPage.login("standard_user", "secret_sauce");
            inventoryPage.addTwoProductsToCart();
            inventoryPage.goToCart();
            cartPage.clickCheckout();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    // ✅ Test: Enter valid checkout information
    @Test
    public void testEnterCheckoutInformation() {
        checkoutPage.enterCheckoutInformation("John", "Doe", "12345");

        // Verify the overview page is displayed
        Assert.assertTrue(checkoutPage.isOverviewPageDisplayed(), "User should be navigated to the overview page.");
    }
}