package Test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import page.Loginpage;

import java.time.Duration;

public class LoginTest {

    WebDriver driver;
    Loginpage loginPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver-win64//chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        loginPage = new Loginpage(driver);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    // ✅ Test: Valid login credentials
    @Test
    public void testValidLogin() throws InterruptedException {
        loginPage.login("standard_user", "secret_sauce");
        Assert.assertTrue(loginPage.isLoginSuccessful(), "Login should be successful with valid credentials.");
    }

    // ❌ Test: Invalid login credentials
    @Test
    public void testInvalidLogin() throws InterruptedException {
        loginPage.login("invalid_user", "invalid_pass");
        Assert.assertFalse(loginPage.isLoginSuccessful(), "Login should fail with invalid credentials.");
    }

    // ⚙️ Test: Login button is enabled
    @Test
    public void testLoginButtonEnabled() {
        Assert.assertTrue(loginPage.isLoginButtonEnabled(), "Login button should be enabled on page load.");
    }

    // 🎨 Test: Login button color
    @Test
    public void testLoginButtonColor() {
        String actualColor = loginPage.getLoginButtonColor();
        System.out.println("Login button color: " + actualColor);
        // Default expected color on SauceDemo login button: rgba(226,35,26,1) (may vary)
        Assert.assertTrue(actualColor.contains("rgba") || actualColor.contains("#"),
                "Login button color should be a valid CSS color.");
    }
}