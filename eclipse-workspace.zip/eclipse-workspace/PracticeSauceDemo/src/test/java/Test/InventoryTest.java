package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import page.Loginpage;
import page.InventoryPage;

import java.time.Duration;

public class InventoryTest {

    WebDriver driver;
    Loginpage loginPage;
    InventoryPage inventoryPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver-win64//chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        
        // Login before reaching inventory page
        loginPage = new Loginpage(driver);
        inventoryPage = new InventoryPage(driver);
        try {
            loginPage.login("standard_user", "secret_sauce");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    // ✅ Test: Add two products to the cart and verify cart badge
    @Test
    public void testAddTwoProductsToCart() {
        inventoryPage.addTwoProductsToCart();

        // Verify cart badge has count 2
        WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
        String actualCount = cartBadge.getText();
        Assert.assertEquals(actualCount, "2", "Cart badge should show 2 items added.");
    }

    // ✅ Test: Go to cart page after adding items
    @Test
    public void testGoToCartPage() {
        inventoryPage.addTwoProductsToCart();
        inventoryPage.goToCart();

        // Validate URL contains 'cart'
        String currentURL = driver.getCurrentUrl();
        Assert.assertTrue(currentURL.contains("cart"), "Should navigate to cart page.");
    }
}
