package InstanceBlocks;

public class class1 {
	class1(){
		System.out.println("0 arg constructor");
	}
//	instance block will print first and then the constructor will print
	{
		System.out.println("instance block");
	}
	public static void main(String[] args) {
		new class1();
	}

}
