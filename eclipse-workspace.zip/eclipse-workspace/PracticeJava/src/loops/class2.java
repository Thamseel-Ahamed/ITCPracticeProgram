package loops;

public class class2 {
 public static void main(String[] args) {
	 int n = 1;
	 switch(n++) {
	 case 1:
		 System.out.println("Hi team");
		 break;
	 case 2:
		 System.out.println("Hello team");
		 break;
	 case 3:
		 System.out.println("Bye team");
		 break;
	 }
 }
}
