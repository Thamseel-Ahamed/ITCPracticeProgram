package Inheritance;
class Q{
	Q(){
		System.out.println("parent 0 Arg Constructor");
	}
}
public class class2 extends Q{
	class2(){
		this(10);
		System.out.println("Child 0 Arg Constructor");
	}
	class2(int a){
		super();
		System.out.println("Child 1 Arg Constructor");
	}
public static void main(String[] args) {
	new class2();
}
}
