package Methods;

public class Method_class1 {
	void m1() {
		System.out.println("m1 Method");
	}
	static void m2() {
		System.out.println("m2 Method");
	}
	public static void main(String[] args) {
		Method_class1 t= new Method_class1();
		t.m1();
		Method_class1.m2();
	}

}
