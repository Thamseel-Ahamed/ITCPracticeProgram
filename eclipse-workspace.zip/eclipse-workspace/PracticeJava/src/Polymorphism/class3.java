package Polymorphism;
//Method overriding
class Shape{
	void draw() {
		System.out.println("no shape");
	}
}
class circle extends Shape{
	void draw() {
		System.out.println("Drawing circle");
	}
}
class rectangle extends Shape{
	void draw() {
		System.out.println("Drawing rectangle");
	}
}
class triangle extends Shape{
	void draw() {
		System.out.println("Drawing Triangle");
	}
}

public class class3 {
public static void main(String[] args) {
	Shape obj = new circle();
	Shape obj1 =new triangle();
	Shape obj2 =new rectangle();
	obj.draw();
	obj1.draw();
	obj2.draw();
}

}
