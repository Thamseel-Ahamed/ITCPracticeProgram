package Polymorphism;
//Operator overLoading
public class class2 {
public static void main(String[] args) {
	System.out.println(10+20);
	System.out.println("Thamseel" + "Ahamed");
	System.out.println(10+ "Ahamed");
	System.out.println("Thamseel" +10+ "Ahamed");
	
	
}
}
