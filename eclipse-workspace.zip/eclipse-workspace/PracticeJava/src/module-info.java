/**
 * 
 */
/**
 * 
 */
module PracticeJava {
	requires java.base;
}