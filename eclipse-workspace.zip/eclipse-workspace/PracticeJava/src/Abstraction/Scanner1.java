
package Abstraction;
import java.util.*;
public class Scanner1 {
	public static double age() {
		Scanner in = new Scanner(System.in);
		boolean valid = false;
		double input =0;
		while(!valid) {
			System.out.println("Enter your age <100 :");
			input = in.nextDouble();
			if(input>0 && input<100) {
				valid=true;
				System.out.println("this is crt age");
			}
			else {
				System.out.println("Sorry! Invalid input");
				
			}
		}
		return input;
	}
	public static void main(String[] args) {
		double a=age();
		System.out.println(a);
}
}
