package Exception;

public class class1 {
	public static void main(String[] args) {
		System.out.println("Hi World");
		System.out.println("Hi World");
		System.out.println(10/0);
		System.out.println("Hi World");
		System.out.println("Hi World");
		
	}

}
