package constructor;

public class class2 {
	int eid; // 0
	String ename; //null
	float esal; //0.0
	
	void disp() {
		System.out.println("Emp ID : "+ eid);
		System.out.println("Emp name : "+ ename);
		System.out.println("Emp salary : "+ esal);
	}
	public static void main(String[] args) {
		class2 emp =new class2(); //default constructor
		emp.disp();
	}
	
}
