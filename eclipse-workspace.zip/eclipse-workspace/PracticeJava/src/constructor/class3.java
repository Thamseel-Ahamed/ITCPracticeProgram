package constructor;

public class class3 {
	int eid;
	String ename;
	float esal;
	
	class3(){
		eid = 1001;
		ename = "Thamseel";
		esal = 25000;
	}
	void disp() {
		System.out.println("Emp ID :" + eid);
		System.out.println("Emp name :" + ename);
		System.out.println("Emp salary :" + esal);
	}
	public static void main(String[] args) {
		class3 emp = new class3();
		emp.disp();
	}

}
