package POM;

public class LoginPage {

}
