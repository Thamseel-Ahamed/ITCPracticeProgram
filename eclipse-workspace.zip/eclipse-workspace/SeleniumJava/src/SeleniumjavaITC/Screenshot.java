package SeleniumjavaITC;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;
public class Screenshot {
	public static void main(String[] args) throws InterruptedException, IOException{
		
	System.setProperty("webdriver.chrome.driver","C:\\Users\\LabsKraft\\Downloads\\chromedriver-win64\\chromedriver-win64/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	
    
 // Step 2: Open a webpage
    driver.get("https://www.google.com/search?q=vijay&oq=vijay&gs_lcrp=EgZjaHJvbWUqBwgAEAAYjwIyBwgAEAAYjwIyCggBEC4YsQMYgAQyDQgCEAAYgwEYsQMYgAQyDQgDEC4YgwEYsQMYgAQyDQgEEC4YgwEYsQMYgAQyBwgFEC4YgAQyCggGEAAYsQMYgAQyCggHEC4YsQMYgAQyBwgIEC4YgAQyDQgJEAAYgwEYsQMYgATSAQg3MDA5ajBqN6gCALACAA&sourceid=chrome&ie=UTF-8&sei=mbdsaK3qGPOZseMPsLOTkQg");
    Thread.sleep(10000);
    // Step 3: Take screenshot and store it as a file
    File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    // Step 4: Define target file location
    File destination = new File("C:\\Users\\LabsKraft\\Pictures\\photo\\vijay.png");
    // Step 5: Copy the screenshot to destination
    Files.copy(screenshot, destination);
    System.out.println("Screenshot saved as: " + destination.getAbsolutePath());
    // Step 6: Close the browser
    driver.quit();

	}
}