package SeleniumjavaITC;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.Select;
public class alert {
	public static void main(String[] args) throws InterruptedException{
		
	System.setProperty("webdriver.chrome.driver","C:\\Users\\LabsKraft\\Downloads\\chromedriver-win64\\chromedriver-win64/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://the-internet.herokuapp.com/javascript_alerts");
    Thread.sleep(1000);
	
	 WebElement jsAlertBtn = driver.findElement(By.xpath("//button[text()='Click for JS Alert']"));
     jsAlertBtn.click();
     Thread.sleep(1000);
     Alert alert1 = (Alert) driver.switchTo().alert();
     System.out.println("Alert says: " + alert1.getText());
     alert1.accept(); // Accept the alert
     Thread.sleep(1000);
     
  // -------- Handle JavaScript Confirm (Dismiss) --------
     WebElement jsConfirmBtn = driver.findElement(By.xpath("//button[text()='Click for JS Confirm']"));
     jsConfirmBtn.click();
     Thread.sleep(1000);
     Alert alert2 = driver.switchTo().alert();
     System.out.println("Confirmation says: " + alert2.getText());
     alert2.dismiss(); // Dismiss the alert
     Thread.sleep(1000);

//-------- Handle JavaScript Prompt (Send Keys + Accept) --------
     WebElement jsPromptBtn = driver.findElement(By.xpath("//button[text()='Click for JS Prompt']"));
     jsPromptBtn.click();
     Thread.sleep(1000);
     Alert alert3 = driver.switchTo().alert();
     System.out.println("Prompt says: " + alert3.getText());
     Thread.sleep(3000);
     alert3.sendKeys("Thamseel");
     //driver.switchTo().alert3.sendKeys("Thamseel") ;   
     alert3.accept(); // Accept after entering text
     Thread.sleep(1000);
     
     // Print result text
     String resultText = driver.findElement(By.id("result")).getText();
     System.out.println("Final Result: " + resultText);
     driver.quit();
     
     







	
	}

	
}