package SeleniumjavaITC;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class testsample {
	public static void main(String[] args) throws InterruptedException {
		
	System.setProperty("webdriver.chrome.driver","C:\\Users\\LabsKraft\\Downloads\\chromedriver-win64\\chromedriver-win64/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	// Maximize the browser window
    driver.manage().window().maximize();
    // Step 1: Open Google
    driver.get("https://testpages.herokuapp.com/styled/basic-html-form-test.html");
    // Step 2: Locate the search box and type a query
    WebElement username = driver.findElement(By.name("username"));
    username.clear();
    username.sendKeys("Thamseel");
    
    WebElement password = driver.findElement(By.name("password"));
    password.clear();
    password.sendKeys("Thamseel");
    // Step 3: Click the Submit button
    WebElement submitBtn = driver.findElement(By.cssSelector("input[type='submit']"));
    submitBtn.click();
    // Step 4: Wait and verify result
    Thread.sleep(20000);
    // Verify the result page contains submitted data
    String pageSource = driver.getPageSource();
    if (pageSource.contains("mytestuser")) {
        System.out.println("Button click successful, data submitted.");
    } else {
        System.out.println("Submission failed or data not found.");
    }
    // Step 5: Close browser
    driver.quit();
}
}

