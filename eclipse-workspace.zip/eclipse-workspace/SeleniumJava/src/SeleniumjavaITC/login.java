package SeleniumjavaITC;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class login{
	public static void main(String[] args) throws InterruptedException {
		
	System.setProperty("webdriver.chrome.driver","C:\\Users\\LabsKraft\\Downloads\\chromedriver-win64\\chromedriver-win64/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	// Maximize the browser window
    driver.manage().window().maximize();
    // Step 1: Open Google
    driver.get("https://the-internet.herokuapp.com/login");
    // Step 2: Locate the search box and type a query
    WebElement username = driver.findElement(By.id("username"));
    username.clear();
    username.sendKeys("tomsmith");
    
    WebElement password = driver.findElement(By.name("password"));
    password.clear();
    password.sendKeys("SuperSecretPassword!");
    // Step 3: Click the Submit button
    WebElement submitBtn = driver.findElement(By.xpath("//button[@type='submit']"));
    submitBtn.click();
    // Step 4: Wait and verify result
    Thread.sleep(20000);
 
    // Step 5: Close browser
    driver.quit();
}
}


